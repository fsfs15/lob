import asyncio
import logging
import os
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from loupgarou.game import Player, Role, create_roles, plurality_vote, winning_team
from loupgarou.i18n import translate

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("loupgarou")

MIN_PLAYERS = 6
MAX_PLAYERS = 20
DEFAULT_PHASE_SECONDS = 90
def database_path() -> Path:
    return Path(os.getenv("WEREWOLF_DATABASE", "werewolf.sqlite3"))


@dataclass
class Game:
    guild_id: int
    channel: discord.TextChannel
    host_id: int
    max_players: int
    phase_seconds: int
    language: str = "en"
    players: dict[int, Player] = field(default_factory=dict)
    phase: str = "lobby"
    votes: dict[int, int] = field(default_factory=dict)
    night_actions: dict[int, tuple[str, int | tuple[int, ...] | str | None]] = field(default_factory=dict)
    lovers: set[int] = field(default_factory=set)
    witch_heal_available: bool = True
    witch_poison_available: bool = True
    hunter_shot_available: set[int] = field(default_factory=set)
    first_night: bool = True
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    hunter_events: dict[int, asyncio.Event] = field(default_factory=dict)

    @property
    def alive(self) -> list[Player]:
        return [player for player in self.players.values() if player.alive]


games: dict[int, Game] = {}
bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())


def initialize_database() -> None:
    with sqlite3.connect(database_path()) as db:
        db.execute(
            """CREATE TABLE IF NOT EXISTS results (
                user_id INTEGER PRIMARY KEY,
                wins INTEGER NOT NULL DEFAULT 0,
                games INTEGER NOT NULL DEFAULT 0
            )"""
        )


def record_result(game: Game, winner: str) -> None:
    with sqlite3.connect(database_path()) as db:
        for player in game.players.values():
            won = (
                (winner == "werewolves" and player.role == Role.WEREWOLF)
                or (winner == "villagers" and player.role != Role.WEREWOLF)
            )
            db.execute(
                """INSERT INTO results (user_id, wins, games) VALUES (?, ?, 1)
                ON CONFLICT(user_id) DO UPDATE SET
                    wins = wins + excluded.wins, games = games + 1""",
                (player.user_id, int(won)),
            )


def role_label(role: Role, language: str) -> str:
    return translate(language, f"role_{role.name.lower()}")


def role_description(role: Role, language: str) -> str:
    return translate(language, f"desc_{role.name.lower()}")


def interaction_language(interaction: discord.Interaction) -> str:
    return "fr" if str(interaction.locale).startswith("fr") else "en"


class JoinButton(discord.ui.Button):
    def __init__(self, game: Game):
        super().__init__(label=translate(game.language, "join"), style=discord.ButtonStyle.success)
        self.game = game

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.guild_id != self.game.guild_id:
            await interaction.response.send_message(translate(self.game.language, "wrong_server"), ephemeral=True)
            return
        if self.game.phase != "lobby":
            await interaction.response.send_message(translate(self.game.language, "started"), ephemeral=True)
            return
        if interaction.user.id in self.game.players:
            await interaction.response.send_message(translate(self.game.language, "already_joined"), ephemeral=True)
            return
        if len(self.game.players) >= self.game.max_players:
            await interaction.response.send_message(translate(self.game.language, "full"), ephemeral=True)
            return
        self.game.players[interaction.user.id] = Player(interaction.user.id, interaction.user.display_name)
        await interaction.response.send_message(
            translate(
                self.game.language,
                "joined",
                count=len(self.game.players),
                maximum=self.game.max_players,
            ),
            ephemeral=True,
        )
        await self.update_lobby()

    async def update_lobby(self) -> None:
        if self.view and self.view.message:
            await self.view.message.edit(embed=lobby_embed(self.game), view=self.view)


class LobbyView(discord.ui.View):
    def __init__(self, game: Game):
        super().__init__(timeout=None)
        self.game = game
        self.message: discord.Message | None = None
        self.add_item(JoinButton(game))


def lobby_embed(game: Game) -> discord.Embed:
    players = ", ".join(player.name for player in game.players.values()) or translate(game.language, "nobody")
    embed = discord.Embed(
        title=translate(game.language, "lobby_title"),
        color=discord.Color.dark_purple(),
    )
    embed.description = (
        f"{translate(game.language, 'host')}: <@{game.host_id}>\n"
        f"{translate(game.language, 'players')}: **{len(game.players)}/{game.max_players}** (minimum {MIN_PLAYERS})\n\n"
        f"{players}\n\n"
        f"{translate(game.language, 'lobby_instructions')}"
    )
    return embed


class TargetSelect(discord.ui.Select):
    def __init__(
        self,
        game: Game,
        actor_id: int,
        action: str,
        options: list[discord.SelectOption],
        *,
        min_values: int = 1,
        max_values: int = 1,
    ):
        super().__init__(
            placeholder=translate(game.language, "choose_action"),
            min_values=min_values,
            max_values=max_values,
            options=options,
        )
        self.game = game
        self.actor_id = actor_id
        self.action = action

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.user.id != self.actor_id:
            await interaction.response.send_message(translate(self.game.language, "not_for_you"), ephemeral=True)
            return
        if self.action != "hunter" and self.game.phase != "night":
            await interaction.response.send_message(translate(self.game.language, "night_ended"), ephemeral=True)
            return
        if self.action == "witch":
            value: int | tuple[int, ...] | str | None = self.values[0]
        else:
            selected_ids = tuple(int(value) for value in self.values)
            value = selected_ids if len(selected_ids) > 1 else selected_ids[0]
        self.game.night_actions[self.actor_id] = (self.action, value)
        if self.action == "hunter":
            self.game.hunter_events.setdefault(self.actor_id, asyncio.Event()).set()
        await interaction.response.send_message(translate(self.game.language, "action_recorded"), ephemeral=True)
        await interaction.message.edit(content=translate(self.game.language, "action_recorded_message"), view=None)


class ActionView(discord.ui.View):
    def __init__(
        self,
        game: Game,
        actor_id: int,
        action: str,
        options: list[discord.SelectOption],
        *,
        min_values: int = 1,
        max_values: int = 1,
    ):
        super().__init__(timeout=game.phase_seconds)
        self.add_item(
            TargetSelect(
                game,
                actor_id,
                action,
                options,
                min_values=min_values,
                max_values=max_values,
            )
        )


class VoteSelect(discord.ui.Select):
    def __init__(self, game: Game, actor_id: int, options: list[discord.SelectOption]):
        super().__init__(placeholder=translate(game.language, "vote_prompt"), options=options)
        self.game = game
        self.actor_id = actor_id

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.user.id != self.actor_id:
            await interaction.response.send_message(translate(self.game.language, "not_for_you"), ephemeral=True)
            return
        if self.game.phase != "day" or not self.game.players[self.actor_id].alive:
            await interaction.response.send_message(translate(self.game.language, "voting_closed"), ephemeral=True)
            return
        target = int(self.values[0])
        if target not in self.game.players or not self.game.players[target].alive:
            await interaction.response.send_message(translate(self.game.language, "invalid_target"), ephemeral=True)
            return
        self.game.votes[self.actor_id] = target
        await interaction.response.send_message(translate(self.game.language, "vote_recorded"), ephemeral=True)
        await interaction.message.edit(content=translate(self.game.language, "vote_recorded_message"), view=None)


async def send_private_action(
    game: Game,
    player: Player,
    content: str,
    action: str,
    candidates: list[Player],
    *,
    min_values: int = 1,
    max_values: int = 1,
) -> None:
    options = [
        discord.SelectOption(label=candidate.name[:100], value=str(candidate.user_id))
        for candidate in candidates
    ]
    if not options:
        return
    try:
        await (await bot.fetch_user(player.user_id)).send(
            content,
            view=ActionView(game, player.user_id, action, options, min_values=min_values, max_values=max_values),
        )
    except discord.Forbidden:
        logger.info("Could not DM player %s for game in guild %s", player.user_id, game.guild_id)
        game.night_actions[player.user_id] = ("pass", None)


async def run_night(game: Game) -> None:
    game.phase = "night"
    game.night_actions.clear()
    game.votes.clear()
    await game.channel.send(translate(game.language, "night"))

    wolves = [player for player in game.alive if player.role == Role.WEREWOLF]
    seers = [player for player in game.alive if player.role == Role.SEER]
    witches = [player for player in game.alive if player.role == Role.WITCH]
    cupids = [player for player in game.alive if player.role == Role.CUPID and game.first_night]

    for wolf in wolves:
        targets = [player for player in game.alive if player.role != Role.WEREWOLF]
        await send_private_action(game, wolf, translate(game.language, "wolves_action"), "wolf", targets)
    for seer in seers:
        targets = [player for player in game.alive if player.user_id != seer.user_id]
        await send_private_action(game, seer, translate(game.language, "seer_action"), "seer", targets)
    for cupid in cupids:
        targets = [player for player in game.alive]
        await send_private_action(
            game,
            cupid,
            translate(game.language, "cupid_action"),
            "cupid",
            targets,
            min_values=2,
            max_values=2,
        )
    for girl in [player for player in game.alive if player.role == Role.LITTLE_GIRL]:
        wolf_names = ", ".join(player.name for player in wolves)
        try:
            await (await bot.fetch_user(girl.user_id)).send(
                translate(
                    game.language,
                    "little_girl_clue",
                    wolves=wolf_names or translate(game.language, "quiet"),
                )
            )
        except discord.Forbidden:
            pass

    expected = {player.user_id for player in wolves + seers + cupids}
    deadline = asyncio.get_running_loop().time() + game.phase_seconds
    while expected - game.night_actions.keys():
        remaining = deadline - asyncio.get_running_loop().time()
        if remaining <= 0:
            break
        await asyncio.sleep(min(1, remaining))

    wolf_votes = [
        int(value)
        for action, value in game.night_actions.values()
        if action == "wolf" and isinstance(value, int)
    ]
    victim = plurality_vote(wolf_votes)
    for witch in witches:
        actions = []
        if victim is not None and game.witch_heal_available:
            actions.append(discord.SelectOption(label=translate(game.language, "witch_heal"), value="heal"))
        if game.witch_poison_available:
            actions.extend(
                discord.SelectOption(
                    label=translate(game.language, "witch_poison", name=player.name)[:100],
                    value=f"poison:{player.user_id}",
                )
                for player in game.alive
                if player.user_id != witch.user_id
            )
        actions.append(discord.SelectOption(label=translate(game.language, "do_nothing"), value="pass"))
        victim_name = (
            game.players[victim].name
            if victim is not None
            else translate(game.language, "tied_pack")
        )
        try:
            await (await bot.fetch_user(witch.user_id)).send(
                translate(game.language, "witch_action", victim=victim_name),
                view=ActionView(game, witch.user_id, "witch", actions),
            )
        except discord.Forbidden:
            game.night_actions[witch.user_id] = ("witch", "pass")
    if witches:
        witch_ids = {player.user_id for player in witches}
        deadline = asyncio.get_running_loop().time() + game.phase_seconds
        while witch_ids - game.night_actions.keys():
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                break
            await asyncio.sleep(min(1, remaining))

    async with game.lock:
        poisoned: int | None = None
        for actor_id, (action, value) in game.night_actions.items():
            if action == "seer" and value is not None:
                target = game.players[int(value)]
                result = translate(
                    game.language,
                    "is_wolf" if target.role == Role.WEREWOLF else "not_wolf",
                )
                try:
                    await (await bot.fetch_user(actor_id)).send(
                        translate(game.language, "seer_result", name=target.name, result=result)
                    )
                except discord.Forbidden:
                    logger.info("Could not deliver Seer result to player %s", actor_id)
            elif action == "cupid" and isinstance(value, tuple):
                game.lovers = set(value)
                names = " and ".join(game.players[user_id].name for user_id in value)
                try:
                    await (await bot.fetch_user(actor_id)).send(
                        translate(game.language, "cupid_result", names=names)
                    )
                except discord.Forbidden:
                    logger.info("Could not deliver Cupid result to player %s", actor_id)
            elif action == "witch":
                if value == "heal" and victim is not None and game.witch_heal_available:
                    game.witch_heal_available = False
                    victim = None
                elif isinstance(value, str) and value.startswith("poison:") and game.witch_poison_available:
                    poisoned = int(value.split(":", 1)[1])
                    game.witch_poison_available = False

        eliminated = {user_id for user_id in (victim, poisoned) if user_id is not None}
        await eliminate(game, eliminated)
        game.first_night = False
        if await check_game_over(game):
            return
    await run_day(game)


async def eliminate(game: Game, player_ids: set[int]) -> None:
    pending = list(player_ids)
    while pending:
        user_id = pending.pop()
        player = game.players.get(user_id)
        if player is None or not player.alive:
            continue
        player.alive = False
        await game.channel.send(
            translate(
                game.language,
                "eliminated",
                name=player.name,
                role=role_label(player.role, game.language),
            )
        )
        if user_id in game.lovers:
            for lover_id in game.lovers - {user_id}:
                if game.players[lover_id].alive:
                    pending.append(lover_id)
        if player.role == Role.HUNTER and user_id not in game.hunter_shot_available:
            game.hunter_shot_available.add(user_id)
            targets = [candidate for candidate in game.alive if candidate.user_id != user_id]
            options = [
                discord.SelectOption(label=candidate.name[:100], value=str(candidate.user_id))
                for candidate in targets
            ]
            if options:
                try:
                    game.hunter_events[user_id] = asyncio.Event()
                    await (await bot.fetch_user(user_id)).send(
                        translate(game.language, "hunter_action"),
                        view=ActionView(game, user_id, "hunter", options),
                    )
                    try:
                        await asyncio.wait_for(game.hunter_events[user_id].wait(), timeout=game.phase_seconds)
                        action, target = game.night_actions.pop(user_id, ("pass", None))
                        if action == "hunter" and isinstance(target, int):
                            pending.append(target)
                    except asyncio.TimeoutError:
                        logger.info("Hunter action timed out for player %s", user_id)
                except discord.Forbidden:
                    logger.info("Could not deliver Hunter action to player %s", user_id)


async def run_day(game: Game) -> None:
    game.phase = "day"
    game.votes.clear()
    await game.channel.send(translate(game.language, "day"))
    options = [
        discord.SelectOption(label=player.name[:100], value=str(player.user_id))
        for player in game.alive
    ]
    for player in game.alive:
        try:
            await (await bot.fetch_user(player.user_id)).send(
                translate(game.language, "day_vote"),
                view=VoteView(game, player.user_id, options),
            )
        except discord.Forbidden:
            logger.info("Could not DM player %s to request a vote", player.user_id)

    deadline = asyncio.get_running_loop().time() + game.phase_seconds
    while len(game.votes) < len(game.alive):
        remaining = deadline - asyncio.get_running_loop().time()
        if remaining <= 0:
            break
        await asyncio.sleep(min(1, remaining))

    target = plurality_vote(game.votes.values())
    if target is None:
        await game.channel.send(translate(game.language, "vote_tie"))
    else:
        async with game.lock:
            await eliminate(game, {target})
    if await check_game_over(game):
        return
    await run_night(game)


class VoteView(discord.ui.View):
    def __init__(self, game: Game, actor_id: int, options: list[discord.SelectOption]):
        super().__init__(timeout=game.phase_seconds)
        self.add_item(VoteSelect(game, actor_id, options))


async def check_game_over(game: Game) -> bool:
    winner = winning_team(game.players.values())
    if winner is None:
        return False
    game.phase = "finished"
    record_result(game, winner)
    await game.channel.send(
        translate(game.language, "village_win" if winner == "villagers" else "wolf_win")
    )
    games.pop(game.guild_id, None)
    return True


werewolf = app_commands.Group(name="werewolf", description="Play Loup-Garou / Werewolf")


@werewolf.command(name="start", description="Open a new Werewolf lobby")
@app_commands.describe(
    max_players="Lobby size, from 6 to 20",
    phase_seconds="Seconds allowed for each phase",
    language="Language for game messages",
)
@app_commands.choices(
    language=[
        app_commands.Choice(name="English", value="en"),
        app_commands.Choice(name="Français", value="fr"),
    ]
)
async def start(
    interaction: discord.Interaction,
    max_players: app_commands.Range[int, 6, 20] = MAX_PLAYERS,
    phase_seconds: app_commands.Range[int, 30, 300] = DEFAULT_PHASE_SECONDS,
    language: str = "en",
) -> None:
    if interaction.guild is None or not isinstance(interaction.channel, discord.TextChannel):
        await interaction.response.send_message(
            translate(language, "start_server"), ephemeral=True
        )
        return
    if interaction.guild_id in games:
        await interaction.response.send_message(
            translate(language, "already_active"), ephemeral=True
        )
        return
    game = Game(
        interaction.guild_id,
        interaction.channel,
        interaction.user.id,
        max_players,
        phase_seconds,
        language,
    )
    game.players[interaction.user.id] = Player(interaction.user.id, interaction.user.display_name)
    games[interaction.guild_id] = game
    view = LobbyView(game)
    await interaction.response.send_message(embed=lobby_embed(game), view=view)
    view.message = await interaction.original_response()


@werewolf.command(name="launch", description="Start the lobby (host only)")
async def launch(interaction: discord.Interaction) -> None:
    game = games.get(interaction.guild_id or 0)
    if game is None or game.phase != "lobby":
        await interaction.response.send_message(
            translate(game.language, "no_lobby") if game else "There is no open lobby.",
            ephemeral=True,
        )
        return
    if interaction.user.id != game.host_id:
        await interaction.response.send_message(translate(game.language, "host_only"), ephemeral=True)
        return
    if len(game.players) < MIN_PLAYERS:
        await interaction.response.send_message(
            translate(game.language, "need_players", minimum=MIN_PLAYERS), ephemeral=True
        )
        return
    await interaction.response.defer(ephemeral=True)
    game.phase = "starting"
    assignments = list(zip(game.players.values(), create_roles(len(game.players)), strict=True))
    for player, role in assignments:
        player.role = role
    pack_names = ", ".join(
        player.name for player, role in assignments if role == Role.WEREWOLF
    )
    for player, role in assignments:
        role_message = (
            f"Your secret role is **{role_label(role, game.language)}**.\n"
            f"{role_description(role, game.language)}"
        )
        if role == Role.WEREWOLF:
            role_message += f"\n\nYour fellow werewolves: {pack_names}."
        try:
            await (await bot.fetch_user(player.user_id)).send(role_message)
        except discord.Forbidden:
            game.phase = "finished"
            games.pop(game.guild_id, None)
            await interaction.followup.send(
                translate(game.language, "dm_failed", name=player.name),
                ephemeral=True,
            )
            await game.channel.send(
                translate(game.language, "cancelled_dm", name=player.name)
            )
            return
    await interaction.followup.send(translate(game.language, "starting"), ephemeral=True)
    await interaction.channel.send(translate(game.language, "roles_sent"))
    asyncio.create_task(run_night(game))


@werewolf.command(name="status", description="Show the current game status")
async def status(interaction: discord.Interaction) -> None:
    game = games.get(interaction.guild_id or 0)
    if game is None:
        await interaction.response.send_message(
            translate(interaction_language(interaction), "no_game"), ephemeral=True
        )
        return
    if game.phase == "lobby":
        await interaction.response.send_message(embed=lobby_embed(game), ephemeral=True)
        return
    alive_names = ", ".join(player.name for player in game.alive) or "Nobody"
    await interaction.response.send_message(
        f"{translate(game.language, 'phase')}: **{game.phase}**\n"
        f"{translate(game.language, 'alive')} ({len(game.alive)}): {alive_names}",
        ephemeral=True,
    )


@werewolf.command(name="cancel", description="Cancel the current lobby (host only)")
async def cancel(interaction: discord.Interaction) -> None:
    game = games.get(interaction.guild_id or 0)
    if game is None or game.phase != "lobby":
        await interaction.response.send_message(
            translate(game.language, "no_cancel") if game else "There is no open lobby to cancel.",
            ephemeral=True,
        )
        return
    if interaction.user.id != game.host_id:
        await interaction.response.send_message(
            translate(game.language, "host_only_cancel"), ephemeral=True
        )
        return
    game.phase = "finished"
    games.pop(game.guild_id, None)
    await interaction.response.send_message(translate(game.language, "cancelled"))


@werewolf.command(name="leaderboard", description="Show the top village players")
async def leaderboard(interaction: discord.Interaction) -> None:
    language = interaction_language(interaction)
    with sqlite3.connect(database_path()) as db:
        rows = db.execute(
            "SELECT user_id, wins, games FROM results ORDER BY wins DESC, games DESC LIMIT 10"
        ).fetchall()
    if not rows:
        await interaction.response.send_message(translate(language, "no_results"), ephemeral=True)
        return
    lines = [
        f"**{rank}.** <@{user_id}> — "
        f"{translate(language, 'wins_games', wins=wins, games=played)}"
        for rank, (user_id, wins, played) in enumerate(rows, start=1)
    ]
    await interaction.response.send_message(
        embed=discord.Embed(
            title=translate(language, "leaderboard_title"),
            description="\n".join(lines),
        )
    )


@werewolf.command(name="stats", description="Show your Werewolf statistics")
async def stats(interaction: discord.Interaction) -> None:
    language = interaction_language(interaction)
    with sqlite3.connect(database_path()) as db:
        row = db.execute(
            "SELECT wins, games FROM results WHERE user_id = ?",
            (interaction.user.id,),
        ).fetchone()
    wins, played = row if row else (0, 0)
    await interaction.response.send_message(
        translate(language, "stats", wins=wins, games=played),
        ephemeral=True,
    )


bot.tree.add_command(werewolf)


@bot.event
async def on_ready() -> None:
    await bot.tree.sync()
    logger.info("Logged in as %s", bot.user)


def main() -> None:
    load_dotenv()
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("Set DISCORD_TOKEN in the environment or in a .env file.")
    initialize_database()
    bot.run(token)


if __name__ == "__main__":
    main()
