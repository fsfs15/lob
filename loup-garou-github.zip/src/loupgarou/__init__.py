"""Loup-Garou Discord bot."""
