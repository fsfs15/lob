from dataclasses import dataclass
from enum import StrEnum
from collections import Counter
from typing import Iterable
import random


class Role(StrEnum):
    WEREWOLF = "Werewolf"
    VILLAGER = "Villager"
    SEER = "Seer"
    WITCH = "Witch"
    CUPID = "Cupid"
    HUNTER = "Hunter"
    LITTLE_GIRL = "Little Girl"


@dataclass
class Player:
    user_id: int
    name: str
    role: Role | None = None
    alive: bool = True


def create_roles(player_count: int, rng: random.Random | None = None) -> list[Role]:
    if not 6 <= player_count <= 20:
        raise ValueError("Games require between 6 and 20 players.")

    wolves = max(2, player_count // 4)
    roles = [Role.WEREWOLF] * wolves
    roles.extend([Role.SEER, Role.WITCH, Role.CUPID, Role.HUNTER])
    if player_count >= 10:
        roles.append(Role.LITTLE_GIRL)
    roles.extend([Role.VILLAGER] * (player_count - len(roles)))
    (rng or random).shuffle(roles)
    return roles


def plurality_vote(votes: Iterable[int]) -> int | None:
    counts = Counter(votes)
    if not counts:
        return None
    highest = max(counts.values())
    leaders = [target for target, count in counts.items() if count == highest]
    return leaders[0] if len(leaders) == 1 else None


def winning_team(players: Iterable[Player]) -> str | None:
    alive = [player for player in players if player.alive]
    wolves = sum(player.role == Role.WEREWOLF for player in alive)
    villagers = len(alive) - wolves
    if wolves == 0:
        return "villagers"
    if wolves >= villagers:
        return "werewolves"
    return None
