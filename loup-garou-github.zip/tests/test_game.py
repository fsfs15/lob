import random

import pytest

from loupgarou.game import Player, Role, create_roles, plurality_vote, winning_team
from loupgarou.i18n import translate


@pytest.mark.parametrize("count", range(6, 21))
def test_role_distribution_has_exact_player_count_and_winnable_teams(count: int) -> None:
    roles = create_roles(count, random.Random(12))

    assert len(roles) == count
    assert roles.count(Role.WEREWOLF) == max(2, count // 4)
    assert Role.SEER in roles
    assert Role.WITCH in roles
    assert Role.CUPID in roles
    assert Role.HUNTER in roles
    assert (count >= 10) == (Role.LITTLE_GIRL in roles)


@pytest.mark.parametrize("count", [5, 21])
def test_role_distribution_rejects_out_of_range_player_counts(count: int) -> None:
    with pytest.raises(ValueError, match="between 6 and 20"):
        create_roles(count)


def test_plurality_vote_returns_unique_winner_or_none() -> None:
    assert plurality_vote([4, 4, 9]) == 4
    assert plurality_vote([4, 9]) is None
    assert plurality_vote([]) is None


def test_winning_team_uses_living_players_only() -> None:
    players = [
        Player(1, "wolf", Role.WEREWOLF),
        Player(2, "villager", Role.VILLAGER),
        Player(3, "villager2", Role.VILLAGER),
        Player(4, "seer", Role.SEER, alive=False),
    ]

    assert winning_team(players) is None
    players[1].alive = False
    assert winning_team(players) == "werewolves"
    players[0].alive = False
    assert winning_team(players) == "villagers"


def test_translation_supports_french_and_falls_back_for_unknown_language() -> None:
    assert translate("fr", "joined", count=4, maximum=12) == "Vous avez rejoint le salon (4/12)."
    assert translate("unsupported", "joined", count=4, maximum=12) == "You joined the lobby (4/12)."
